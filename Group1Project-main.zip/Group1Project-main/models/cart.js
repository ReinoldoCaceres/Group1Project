// Import
let mongoose = require('mongoose');

// Create a model class
let cartModel = mongoose.Schema(
    {
        name: String,
        price: String,
        
    },
    {
        collection: "cart"
    }
);

module.exports = mongoose.model("cart", cartModel);