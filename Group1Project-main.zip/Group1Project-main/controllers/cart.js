let messageModel = require("../models/message");
let productModel = require("../models/products");
let cartModel = require("../models/carts");
let sgMail = require("@sendgrid/mail");


// Renders the Add form using the add_edit.ejs template
module.exports.displayAddPage = (req, res, next) => {
  let newProduct = cartModel();

  res.render("carts/cart-add-form", {
    title: "carts",
    cart: newProduct,
  });
};

// Processes the data submitted from the Add form to create a new event
module.exports.processAddPage = (req, res, next) => {
   
  let newProduct = cartModel({
    _id: req.params.id,
    name: req.body.name,
    price: req.body.price,

  });

  messageModel.create(newProduct, (err, item) => {
    if (err) {
      console.log(err);
      res.end(err);
    } else {
      // refresh the book list
      console.log(item);
      res.redirect("/carts/list");
    }
  });
  
};

// Gets all messages from the Database and renders the page to list them all.
module.exports.cartList = function (req, res, next) {
      cartModel.find((err, cartList) => {
    if (err) {
      return console.error(err);
    } else {
      res.render("carts/carts-list", {
        title: "carts List",
        cartList: cartList,
        userName: req.user ? req.user.username : "",
      });
    }
  });
};


// Deletes a message based on its id.
module.exports.performDelete = (req, res, next) => {
  let id = req.params.id;

     cartModel.remove({ _id: id }, (err) => {
    if (err) {
      console.log(err);
      res.end(err);
    } else {
      // refresh the book list
      res.redirect("carts/list");
    }
  });
};
